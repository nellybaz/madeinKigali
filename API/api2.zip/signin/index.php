<?php

include("../functions/functions.php");

if(isset($_POST['request']) && json_decode($_POST['token']) == "mik9876543210"){
    $request = json_decode($_POST['request']);
    $tag = $request['tag'];
    $res = [];
   
    //login
    if($tag == "login"){
        if(login($email, $password) == 1){
            $res = array("res: 1");
        }

        else{
            $res = array("res: 0");

        }
    }


    //registering
    else if($tag == "register"){
        if(register($name, $email, $password) == 1){
            $res  = array("res: 1");
        }

        else{
            $res = array("res: 0");
        }

    }
    
}

header("Content-Type: application/json");
echo json_encode($res);