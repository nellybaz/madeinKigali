<?php

$SERVER_NAME = "localhost";
$USER_NAME = "developer1mik";
$PASSWORD = "developer1@madeinkigali";
$DATABASE_NAME = "madeinkigali";
$con = new mysqli($SERVER_NAME, $USER_NAME, $PASSWORD, $DATABASE_NAME);

if($con->connect_error){
    die("sconnection failed: ". $con->connect_error );
}

