<?php
include("../config/connection.php");
//================= all functions for database interaction====================//
$ROW = '';
function login($email, $password){
    // $statement = $con->prepare("SELECT * FROM users WHERE email = '?' AND pword = '?' LIMIT 1");

    // $statement->bind_param("ss", $email, $password);
    // $statement->execute();
    // $statement->close();

    $sql = "SELECT * FROM users WHERE email = $email AND pword = $password LIMIT 1";

    $result = $con->query($sql);

    //successful
    if($result->num_rows > 0){
        return 1;
    }

    //unsuceesful
    return 0;

}


function register($name, $email, $password){
    $statement = $con->prepare("INSERT INTO users ('name','email','pword') VALUES (?,?,?)");

    $statement->bind_param("sss", $name, $email, $password);
   if($statement->execute()){
       return 1;
   } 
    $statement->close();


    return 0;
}

function flash_deals(){
    $sql = "SELECT * FROM products WHERE product_id in (SELECT product_id FROM flash_deals)";

    $result = $con->query($sql);

    //successful
    if($result->num_rows > 0){
        global $ROW;
        $ROW = $result->fetch_assoc();
        
        return 1;
    }

    //unsuceesful
    return 0;
}


function trending(){
    $sql = "SELECT * FROM trending";

    $result = $con->query($sql);

    //successful
    if($result->num_rows > 0){
        global $ROW;
        $ROW = $result->fetch_assoc();
        
        return 1;
    }

    //unsuceesful
    return 0;
}

function search($string){
    $sql = "SELECT prd_name, brand, price FROM products WHERE prd_name LIKE '%$string%' OR category LIKE '%$string%'";

    $result = $con->query($sql);

    //successful
    if($result->num_rows > 0){
        global $ROW;
        $ROW = $result->fetch_assoc();
        
        return 1;
    }

    //unsuceesful
    return 0;
}


function single_product($string){
    $sql = "SELECT * FROM products WHERE prd_name = $string LIMIT 1";

    $result = $con->query($sql);

    //successful
    if($result->num_rows > 0){
        global $ROW;
        $ROW = $result->fetch_assoc();
        
        return 1;
    }

    //unsuceesful
    return 0;
}


function add_product($name, $id, $price, $img, $cat, $subcat, $brand, $sex, $size, $instock){

    $statement = $con->prepare("INSERT INTO products ('product_id', 'product_name','product_price', 'primary_img', 'product_cat', 'product_subcat', 'product_brand', 'sex', 'product_size', 'instock') VALUES (?,?,?,?,?,?,?,?,?,?)");

    $statement->bind_param("ssssssssss", $name, $id, $price, $img, $cat, $subcat, $brand, $sex, $size, $instock);
   if($statement->execute()){
       return 1;
   } 
    $statement->close();


    return 0;

}